package com.example.bebaagua

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class TeladeLogin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_telade_login)
    }
}